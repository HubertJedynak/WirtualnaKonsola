package com.example.kiryu.udppad;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class MainActivity extends AppCompatActivity {

    ImageView ivStart,ivSelect,ivGora,ivDol,ivLewo,ivPrawo,ivKolko,ivKrzyzyk,ivTrojkat,ivKwadrat,ivPolacz;
    EditText etIPHosta;

    String czyWcisnietyStart="0",czyWcisnietySelect="0";
    String czyWcisnietyGora="0",czyWcisnietyDol="0",czyWcisnietyLewo="0",czyWcisnietyPrawo="0";
    String czyWcisnietyKolko="0",czyWcisnietyKrzyzyk="0",czyWcisnietyTrojkat="0",czyWcisnietyKwadrat="0";

    static float polozenieLewoPrawo,getPolozenieGoraDol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        Log.d("qaqa","start");
        ivStart=findViewById(R.id.start);
        ivStart.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    czyWcisnietyStart="1";
                    ustawIkone(ivStart,R.drawable.start0n);
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyStart="0";
                    ustawIkone(ivStart,R.drawable.start);
                }
                return true;
            }
        });
        ivSelect=findViewById(R.id.select);
        ivSelect.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    czyWcisnietySelect="1";
                    ustawIkone(ivSelect,R.drawable.select0n);
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietySelect="0";
                    ustawIkone(ivSelect,R.drawable.select);
                }
                return true;
            }
        });
        ivGora=findViewById(R.id.gora);
        ivGora.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    czyWcisnietyGora="1";
                    ustawIkone(ivGora,R.drawable.gora0n);
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyGora="0";
                    ustawIkone(ivGora,R.drawable.gora);
                }
                return true;
            }
        });
        ivDol=findViewById(R.id.dol);
        ivDol.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    czyWcisnietyDol="1";
                    ustawIkone(ivDol,R.drawable.dol0n);
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyDol="0";
                    ustawIkone(ivDol,R.drawable.dol);
                }
                return true;
            }
        });
        ivLewo=findViewById(R.id.lewo);
        ivLewo.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){

                    czyWcisnietyLewo="1";
                    ustawIkone(ivLewo,R.drawable.lewo0n);
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    ustawIkone(ivLewo,R.drawable.lewo);
                    czyWcisnietyLewo="0";
                }
                return true;
            }
        });
        ivPrawo=findViewById(R.id.prawo);
        ivPrawo.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    ustawIkone(ivPrawo,R.drawable.prawo0n);
                    czyWcisnietyPrawo="1";
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyPrawo="0";
                    ustawIkone(ivPrawo,R.drawable.prawo);
                }
                return true;
            }
        });
        ivKolko=findViewById(R.id.kolo);
        ivKolko.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    ustawIkone(ivKolko,R.drawable.kolo0n);
                    czyWcisnietyKolko="1";
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    ustawIkone(ivKolko,R.drawable.kolo);
                    czyWcisnietyKolko="0";
                }
                return true;
            }
        });
        ivKrzyzyk=findViewById(R.id.krzyzyk);
        ivKrzyzyk.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    ustawIkone(ivKrzyzyk,R.drawable.krzyzyk0n);
                    czyWcisnietyKrzyzyk="1";
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyKrzyzyk="0";
                    ustawIkone(ivKrzyzyk,R.drawable.krzyzyk);
                }
                return true;
            }
        });
        ivTrojkat=findViewById(R.id.trojkat);
        ivTrojkat.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    ustawIkone(ivTrojkat,R.drawable.trojkat0n);
                    czyWcisnietyTrojkat="1";
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyTrojkat="0";
                    ustawIkone(ivTrojkat,R.drawable.trojkat);

                }
                return true;
            }
        });
        ivKwadrat=findViewById(R.id.kwadrat);
        ivKwadrat.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN){
                    ustawIkone(ivKwadrat,R.drawable.kwadrat0n);
                    czyWcisnietyKwadrat="1";
                }else if(event.getAction()== MotionEvent.ACTION_UP){
                    czyWcisnietyKwadrat="0";
                    ustawIkone(ivKwadrat,R.drawable.kwadrat);
                }
                return true;
            }
        });
        ivPolacz=findViewById(R.id.polacz);
        etIPHosta=findViewById(R.id.adresHosta);
        sensor();
    }

    public void sensor(){
        Sensor sensor;
        SensorManager sensorManager;
        SensorEventListener sensorEventListener;

        sensorEventListener=new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                polozenieLewoPrawo=event.values[1];
                getPolozenieGoraDol=event.values[2];
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        };
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        sensor=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(sensorEventListener,sensor,SensorManager.SENSOR_DELAY_GAME);
    }

    public void polacz(View view) {
        Log.d("qaqa","jestem w polacz");
        Wysylanie wysylanie=new Wysylanie();
        wysylanie.execute();
    }
    private class Wysylanie extends AsyncTask {

        InetAddress ia;
        DatagramSocket ds;
        DatagramPacket dpWyslij;
        String ipHosta;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            ipHosta=etIPHosta.getText().toString();
            Log.d("qaqa",ipHosta);
        }

        @Override
        protected Object doInBackground(Object[] objects){
            try{

                ia= InetAddress.getByName(ipHosta);
                ds=new DatagramSocket(6000);
                ///////////////////////////
                Szyfrowanie szyfrowanie=new Szyfrowanie();
                szyfrowanie.proceduraWstepna(ds,dpWyslij,ia);
                //////////////////////


                String napis;
                while(true) {
                    int lewoPrawo=(int)((polozenieLewoPrawo+50)*10);
                    int goraDol=(int)((getPolozenieGoraDol+50)*10);

                    //napis =String.valueOf(lewoPrawo)+" "+String.valueOf(goraDol)+" "+wcisnieteGuziki();
                    napis =String.valueOf(lewoPrawo)+""+String.valueOf(goraDol)+""+wcisnieteGuziki();
   //                 Log.d("qaqa","niezaszyfrowane "+napis);
                    Log.d("qaqa","zaszyfrowane ilosc bitow"+szyfrowanie.zaszyfruj(napis).getBytes().length);
                    String napisZaszyfrowany=szyfrowanie.zaszyfruj(napis);
                    byte[] bytes;

                    bytes = napisZaszyfrowany.getBytes();
                    dpWyslij = new DatagramPacket(bytes, bytes.length, ia, 6000);
   //                 Log.d("qaqa","ile bajtow " +bytes.length+" napis: "+napisZaszyfrowany);
                    Thread.sleep(30);
                    ds.send(dpWyslij);
                }
            }catch (Exception e){}
            return null;
        }

        public String wcisnieteGuziki(){
            return czyWcisnietyStart+""+czyWcisnietySelect+""+czyWcisnietyGora+""+czyWcisnietyDol
                    +""+czyWcisnietyLewo+""+czyWcisnietyPrawo+""+czyWcisnietyKolko+""+
                    czyWcisnietyKrzyzyk+""+czyWcisnietyTrojkat+""+czyWcisnietyKwadrat;

        }

    }

    public void ustawIkone(ImageView imageView, int id){
        Drawable drawable= ContextCompat.getDrawable(this,id);
        Bitmap bitmap= ((BitmapDrawable)drawable).getBitmap();
        imageView.setImageBitmap(bitmap);
    }

}
