package com.example.kiryu.udppad;

import android.util.Log;

import java.io.IOException;
import java.math.BigInteger;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * Created by kiryu on 2018-12-15.
 */

public class Szyfrowanie {
    // dane do klucza szyfrujacego
    BigInteger bIE;
    BigInteger bIN;

    public void proceduraWstepna(DatagramSocket ds, DatagramPacket dpWyslij, InetAddress ia) throws Exception {
        // wyslanie info ze chce sie polaczyc
        String napis ="prosze o polaczenie";

        byte[] bytes;

        bytes = napis.getBytes();
        dpWyslij = new DatagramPacket(bytes, bytes.length, ia, 6000);
        Log.d("qaqa","ile bajtow " +bytes.length+"guziki: "+napis);
        Thread.sleep(100);
        ds.send(dpWyslij);
 //        odbierz e publiczne

        byte[] b=new byte[4000];
        DatagramPacket dppobierz = new DatagramPacket(b, b.length);
        ds.receive(dppobierz);
        String e=new String(dppobierz.getData());
        Log.d("qaqa","e "+e.trim());

        // odbierz n publiczne

        b=new byte[4000];
        dppobierz = new DatagramPacket(b, b.length);
        ds.receive(dppobierz);
        String n=new String(dppobierz.getData());
        Log.d("qaqa","n "+n.trim());

        // utworz klucz szyfrujacy z pozyskanych danych
        bIE=new BigInteger(e.trim());
        bIN=new BigInteger(n.trim());


    }

    public String zaszyfruj(String napis){
        BigInteger bi=new BigInteger(napis);

        return (bi.modPow(bIE,bIN)).toString();
    }

}
